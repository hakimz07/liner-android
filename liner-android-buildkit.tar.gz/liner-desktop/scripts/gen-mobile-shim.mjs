// Generates public/mobile-shim.js: a classic (non-module) script that provides
// window.linerElectron for an Android WebView / Capacitor build. It ports the
// Electron main-process WASM signer (electron/crypto.ts + signer.ts) to browser
// APIs (Web Crypto + TextEncoder + TextDecoder), stores auth in localStorage,
// and stubs all desktop-only IPC methods.
import { readFileSync, writeFileSync, mkdirSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const signerSrc = readFileSync(resolve(root, "electron/signer.ts"), "utf8");

// Extract the base64 literal: everything between first '"' and last '"' on the
// line that defines SIGNER_WASM_BASE64.
const line = signerSrc.split("\n").find((l) => l.includes("SIGNER_WASM_BASE64"));
if (!line) throw new Error("SIGNER_WASM_BASE64 not found");
const first = line.indexOf('"');
const last = line.lastIndexOf('"');
if (first < 0 || last <= first) throw new Error("could not parse wasm base64 literal");
const wasmB64 = line.slice(first + 1, last);
console.log(`[gen-mobile-shim] wasm base64 length = ${wasmB64.length}`);

const shim = `/* Liner mobile shim — auto-generated. Provides window.linerElectron in a WebView. */
(function () {
  "use strict";
  var SIGNER_WASM_BASE64 = "${wasmB64}";

  var wasmPromise = null;
  var wasmExports = null;
  function ensureWasm() {
    if (wasmExports) return Promise.resolve(wasmExports);
    if (wasmPromise) return wasmPromise;
    wasmPromise = (function () {
      var bin = Uint8Array.from(atob(SIGNER_WASM_BASE64), function (c) { return c.charCodeAt(0); });
      return WebAssembly.instantiate(bin.buffer.slice(bin.byteOffset, bin.byteOffset + bin.byteLength), {})
        .then(function (result) {
          wasmExports = result.instance.exports;
          return wasmExports;
        });
    })();
    return wasmPromise;
  }

  function passString(exports, str) {
    var bytes = new TextEncoder().encode(String(str));
    var ptr = exports.liner_alloc(bytes.length);
    var view = new Uint8Array(exports.memory.buffer, ptr, bytes.length);
    view.set(bytes);
    return { ptr: ptr, len: bytes.length, free: function () { exports.liner_dealloc(ptr, bytes.length); } };
  }
  function readResult(exports) {
    var ptr = exports.liner_get_result_ptr();
    var len = exports.liner_get_result_len();
    if (!ptr || len === 0) return "";
    var view = new Uint8Array(exports.memory.buffer, ptr, len);
    return new TextDecoder().decode(view);
  }
  function randomNonce() {
    var a = new Uint8Array(8);
    crypto.getRandomValues(a);
    var s = "";
    for (var i = 0; i < a.length; i++) s += (a[i] < 16 ? "0" : "") + a[i].toString(16);
    return s;
  }

  var serverTimeOffsetMs = 0;
  function getAdjustedTimestamp() { return Math.floor((Date.now() + serverTimeOffsetMs) / 1000); }

  function wasmSign(fnName, input) {
    return ensureWasm().then(function (exports) {
      var timestamp = (input && typeof input.timestamp === "number") ? input.timestamp : getAdjustedTimestamp();
      var nonce = randomNonce();
      var method = passString(exports, String(input.method || "GET").toUpperCase().trim());
      var path = passString(exports, String(input.path || "/").split("?")[0].trim());
      var body = passString(exports, input.body || "");
      var nonceBuf = passString(exports, nonce);
      try {
        var code = exports[fnName](
          method.ptr, method.len, path.ptr, path.len, body.ptr, body.len,
          BigInt(timestamp), nonceBuf.ptr, nonceBuf.len
        );
        if (code !== 0) return { error: "wasm " + fnName + " failed code " + code };
        return { signature: readResult(exports), timestamp: timestamp, nonce: nonce };
      } finally {
        method.free(); path.free(); body.free(); nonceBuf.free();
      }
    });
  }

  function signCoverUrl(payload) {
    return ensureWasm().then(function (exports) {
      var b = passString(exports, payload);
      try {
        var code = exports.liner_sign_cover_url(b.ptr, b.len);
        if (code !== 0) throw new Error("wasm sign_cover_url code " + code);
        return readResult(exports);
      } finally { b.free(); }
    });
  }
  function signRawPayload(payload) {
    return ensureWasm().then(function (exports) {
      var bytes = (payload && payload.buffer) ? new Uint8Array(payload.buffer) : new Uint8Array(payload);
      var ptr = exports.liner_alloc(bytes.length);
      var view = new Uint8Array(exports.memory.buffer, ptr, bytes.length);
      view.set(bytes);
      try {
        var code = exports.liner_sign_raw_payload(ptr, bytes.length);
        if (code !== 0) throw new Error("wasm sign_raw_payload code " + code);
        return readResult(exports);
      } finally { exports.liner_dealloc(ptr, bytes.length); }
    });
  }

  // ---- auth session (localStorage-backed) ----
  var AUTH_KEY = "liner.mobile.auth.session.v1";
  var authListeners = [];
  function readAuth() {
    try { var s = localStorage.getItem(AUTH_KEY); return s ? JSON.parse(s) : null; }
    catch (e) { return null; }
  }
  function writeAuth(session) {
    try {
      if (session) localStorage.setItem(AUTH_KEY, JSON.stringify(session));
      else localStorage.removeItem(AUTH_KEY);
    } catch (e) {}
    for (var i = 0; i < authListeners.length; i++) {
      try { authListeners[i](session); } catch (e) {}
    }
    return session;
  }
  function doRefresh(apiBaseUrl, usedRefreshToken) {
    var current = readAuth();
    var refreshToken = usedRefreshToken || (current && current.refreshToken);
    if (!refreshToken) return Promise.resolve({ outcome: "no_session", session: null });
    var base = String(apiBaseUrl || "https://api.tryliner.fun").replace(/\\/+$/, "");
    return fetch(base + "/v1/auth/refresh", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ refreshToken: refreshToken })
    }).then(function (res) {
      if (!res.ok) return { outcome: "transient", session: readAuth(), reason: "refresh http " + res.status };
      return res.json().then(function (data) {
        if (!data || (!data.accessToken && !data.session)) return { outcome: "transient", session: readAuth(), reason: "malformed" };
        var merged = Object.assign({}, current || {}, {
          accessToken: data.accessToken || (data.session && data.session.accessToken),
          refreshToken: data.refreshToken || (data.session && data.session.refreshToken) || refreshToken,
          accessTokenExpiresAt: data.accessTokenExpiresAt || (data.session && data.session.accessTokenExpiresAt),
          user: data.user || (current && current.user)
        });
        if (!merged.accessToken) return { outcome: "transient", session: readAuth(), reason: "no access token" };
        writeAuth(merged);
        return { outcome: data.refreshToken ? "rotated" : "refreshed", session: merged };
      });
    }).catch(function (err) {
      return { outcome: "transient", session: readAuth(), reason: String(err && err.message || err) };
    });
  }

  // ---- generic stubs ----
  function noop() { return Promise.resolve(); }
  function noopFalse() { return Promise.resolve(false); }
  function noopNull() { return Promise.resolve(null); }
  function noopObj() { return Promise.resolve({}); }
  function unsub() { return function () {}; }

  var api = {
    platform: "android",
    isHyprland: false,
    minimize: noop, toggleMaximize: noop, toggleFullScreen: noop, close: noop,
    isMaximized: function () { return Promise.resolve(false); },
    isFullScreen: function () { return Promise.resolve(false); },
    onWindowStateChange: unsub, onWindowRestored: unsub, onWindowMinimized: unsub,
    dragStart: function () {}, dragMove: function () {}, dragEnd: function () {},
    signRequest: function (input) { return wasmSign("liner_sign_request", input); },
    signMonitorRequest: function (input) { return wasmSign("liner_sign_monitor_request", input); },
    syncServerTime: function (dateHeaderOrMs) {
      var ms = (typeof dateHeaderOrMs === "string") ? Date.parse(dateHeaderOrMs) : dateHeaderOrMs;
      if (typeof ms === "number" && !isNaN(ms) && ms > 0) serverTimeOffsetMs = ms - Date.now();
      return Promise.resolve(serverTimeOffsetMs);
    },
    getServerTimeOffset: function () { return Promise.resolve(serverTimeOffsetMs); },
    signCoverUrl: signCoverUrl,
    signRawPayload: signRawPayload,
    authSession: {
      get: readAuth,
      set: function (next) {
        if (!next) return Promise.resolve(writeAuth(null));
        var cur = readAuth() || {};
        return Promise.resolve(writeAuth(Object.assign({}, cur, { accessToken: next.accessToken, refreshToken: next.refreshToken })));
      },
      refresh: function (input) { return doRefresh(input && input.apiBaseUrl, input && input.refreshToken); },
      onChange: function (cb) { authListeners.push(cb); return function () { var i = authListeners.indexOf(cb); if (i >= 0) authListeners.splice(i, 1); }; }
    },
    onDeeplink: unsub,
    diagnoseNetwork: function () { return noopObj(); },
    openDownloads: noopFalse, openExportFolder: noopFalse, openCacheFolder: noopFalse,
    setAppIcon: noop,
    getAppVersion: function () { return Promise.resolve("0.2.10-android"); },
    getCacheStats: function () { return Promise.resolve({ cacheSize: 0, httpCacheSize: 0, codeCacheSize: 0, serviceWorkerSize: 0, indexedDbSize: 0, localStorageSize: 0, blobStorageSize: 0, cachePath: "" }); },
    clearCoversCache: noopFalse, clearAudioCache: noopFalse, clearHttpCache: noopFalse,
    checkForUpdates: function () { return Promise.resolve({ available: false }); },
    downloadUpdate: function () { return Promise.resolve({ success: false, error: "disabled on mobile" }); },
    quitAndInstall: noopFalse,
    onUpdateAvailable: unsub, onUpdateDownloadProgress: unsub, onUpdateDownloaded: unsub, onUpdateError: unsub,
    bundleCheck: function () { return Promise.resolve({ available: false, reason: "mobile" }); },
    bundleDownloadAndInstall: function () { return Promise.resolve({ success: false, error: "mobile" }); },
    bundleHotSwap: noopFalse, bundleRollback: noopFalse,
    bundleGetStatus: function () { return Promise.resolve({ appVersion: "0.2.10-android", bundleVersion: "0", isOta: false, sha256: null, effectivePath: "" }); },
    onBundleAvailable: unsub, onBundleDownloadProgress: unsub, onBundleReady: unsub, onBundleStamp: unsub,
    touchbarUpdateState: function () {}, onTouchBarAction: unsub, sendTouchBarAction: function () {},
    getTouchBarInitialState: noopNull, onTouchBarRequestSync: unsub,
    overlayUpdateState: function () {}, overlayReady: function () {}, onOverlayAction: unsub,
    sendOverlayAction: function () {}, toggleOverlay: noopFalse, isOverlayOpen: function () { return Promise.resolve(false); },
    closeOverlay: function () {}, onOverlayState: unsub, getOverlayInitialState: noopNull,
    updateOverlaySettings: function () {}, pauseOverlayShortcuts: function () {},
    onOverlaySettingsChanged: unsub, onOverlayVisibility: unsub, setOverlayAuthenticated: function () {},
    discordUpdateState: function () {}, discordUpdateSettings: function () {},
    getDiscordStatus: function () { return Promise.resolve({ connected: false }); },
    mintPoToken: function () { return Promise.reject(new Error("po_token not available on mobile")); },
    youtubeTvSession: function () { return Promise.reject(new Error("youtube tv auth not available on mobile")); },
    youtubeSolveN: function () { return Promise.reject(new Error("youtube n-solver not available on mobile")); }
  };

  window.linerElectron = api;
  ensureWasm().then(function () { console.log("[liner-mobile] wasm signer ready"); })
    .catch(function (e) { console.error("[liner-mobile] wasm signer init failed:", e); });
  console.log("[liner-mobile] window.linerElectron shim installed");
})();
`;

mkdirSync(resolve(root, "public"), { recursive: true });
writeFileSync(resolve(root, "public/mobile-shim.js"), shim);
console.log(`[gen-mobile-shim] wrote public/mobile-shim.js (${shim.length} bytes)`);
