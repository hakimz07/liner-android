import {
  usePlayerStore,
  type PlayerCommand,
  type PlayerStatus,
  type RepeatMode,
  type PlayerState,
} from "../store/playerStore";
import { playerRuntime } from "./playerRuntime";
import { isRadioContext, shouldRefillRadio } from "./radioMode";
import { pitchShifter } from "./pitchShifter";
import {
  api,
  type ApiRadioTrack,
  type LyricsCandidate,
  type LyricsSyncLevel,
  type PlaybackContext,
  type RecordPlaybackEventRequest,
} from "@/shared/api";
import { toClientTrack } from "@/shared/api/track";
import { log } from "@/shared/utils/logger";
import {
  parseRawLyrics,
  useLyricsStore,
  lyricsCache,
  shouldCacheLyricsCandidate,
  compareLyricsCandidates,
  isBetterLyricsCandidate,
  type CachedLyricsItem,
} from "@/features/lyrics";
import { preloadCoverArt } from "@/features/covers";
import { linerDb, type CachedLyricsRecord } from "@/shared/storage";
import { debouncedStorage } from "@/shared/utils/storage";
import { showToast } from "@/shared/ui";
import { createTranslatorSync, getStoredLocale } from "@/languages";
import type { Track } from "@/shared/types";

const MAX_CONSECUTIVE_AUTO_SKIPS = 3;
const SEVEN_DAYS_MS = 7 * 24 * 60 * 60 * 1000;

export { usePlayerStore, type PlayerStatus, type RepeatMode, type PlayerState };

function shuffleArray<T>(array: T[]): T[] {
  const result = [...array];
  for (let i = result.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [result[i], result[j]] = [result[j], result[i]];
  }
  return result;
}

function restoreOriginalRelativeOrder<T>(
  currentUpcoming: T[],
  referenceList: T[],
): T[] {
  if (referenceList.length === 0) return currentUpcoming;
  const originalPosMap = new Map<unknown, number>();
  referenceList.forEach((item: unknown, idx) => {
    const key = (item as { id?: string })?.id ?? item;
    if (!originalPosMap.has(key)) {
      originalPosMap.set(key, idx);
    }
  });

  return [...currentUpcoming].sort((a: unknown, b: unknown) => {
    const keyA = (a as { id?: string })?.id ?? a;
    const keyB = (b as { id?: string })?.id ?? b;
    const posA = originalPosMap.has(keyA)
      ? originalPosMap.get(keyA)!
      : Number.MAX_SAFE_INTEGER;
    const posB = originalPosMap.has(keyB)
      ? originalPosMap.get(keyB)!
      : Number.MAX_SAFE_INTEGER;
    return posA - posB;
  });
}

function parsePlaybackContext(
  context: string | null,
): PlaybackContext | undefined {
  if (!context) return undefined;
  if (context.includes(":")) {
    const [type, ...rest] = context.split(":");
    return { type, id: rest.join(":") };
  }
  return { type: context };
}

// fresh station instance id so the backend can tell paginated waves apart
// even when seed + history windows coincide
function newRadioWaveId(): string {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) {
    return crypto.randomUUID();
  }
  return `wave-${Date.now().toString(36)}-${Math.floor(Math.random() * 0xffffffff).toString(36)}`;
}

type LyricsHint = { title: string; artist: string; durationMs?: number };

function lyricsHint(track: Track): LyricsHint {
  const artist =
    track.artistList?.[0]?.name || track.artists.split(",")[0] || "";
  return {
    title: track.title,
    artist: artist.trim(),
    durationMs: track.durationMs,
  };
}

class PlaybackTelemetryTracker {
  private activeTrackId: string | null = null;
  private activeTrack: Track | null = null;
  private playbackSessionId: string = "";
  private listeningSessionId: string = "";
  private lastActivityTime: number = 0;
  private trackDurationMs = 0;
  private playedDurationMs = 0;
  private lastTickTime: number | null = null;
  private completed = false;
  private loopCount = 0;
  private hasSeekBackward = false;
  private context?: PlaybackContext;
  private readonly SESSION_TIMEOUT_MS = 30 * 60 * 1000;

  private getOrCreateListeningSession(): string {
    const now = Date.now();
    if (
      !this.listeningSessionId ||
      now - this.lastActivityTime > this.SESSION_TIMEOUT_MS
    ) {
      this.listeningSessionId =
        typeof crypto !== "undefined" && "randomUUID" in crypto
          ? crypto.randomUUID()
          : `ls_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`;
    }
    this.lastActivityTime = now;
    return this.listeningSessionId;
  }

  private generatePlaybackSessionId(): string {
    return typeof crypto !== "undefined" && "randomUUID" in crypto
      ? crypto.randomUUID()
      : `ps_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`;
  }

  public startTrack(track: Track, contextStr: string | null) {
    this.flushCurrentTrack();

    this.playbackSessionId = this.generatePlaybackSessionId();
    this.activeTrackId = track.id;
    this.activeTrack = track;
    this.trackDurationMs = track.durationMs ?? 0;
    this.playedDurationMs = 0;
    this.lastTickTime = null;
    this.completed = false;
    this.loopCount = 0;
    this.hasSeekBackward = false;
    this.context = parsePlaybackContext(contextStr);
    this.getOrCreateListeningSession();
  }

  public onPlaying() {
    const now = Date.now();
    this.lastTickTime = now;
    this.lastActivityTime = now;
  }

  public onPausedOrStopped() {
    const now = Date.now();
    this.lastActivityTime = now;
    if (this.lastTickTime !== null) {
      const delta = now - this.lastTickTime;
      if (delta > 0 && delta < 10000) {
        this.playedDurationMs += delta;
      }
      this.lastTickTime = null;
    }
  }

  public onTick(isPlaying: boolean) {
    if (!this.activeTrackId) return;

    const now = Date.now();
    this.lastActivityTime = now;

    if (isPlaying) {
      if (this.lastTickTime !== null) {
        const delta = now - this.lastTickTime;
        if (delta > 0 && delta < 5000) {
          this.playedDurationMs += delta;
        }
      }
      this.lastTickTime = now;
    } else {
      this.lastTickTime = null;
    }
  }

  public recordSeekBackward() {
    this.hasSeekBackward = true;
    this.lastActivityTime = Date.now();
  }

  public onTrackCompleted(isRepeatOne: boolean = false) {
    if (!this.activeTrackId) return;
    this.onPausedOrStopped();
    this.completed = true;
    if (isRepeatOne) {
      this.loopCount += 1;
    }
  }

  public flushCurrentTrack(): Promise<void> {
    if (!this.activeTrackId) return Promise.resolve();
    this.onPausedOrStopped();
    let reported: Promise<void> = Promise.resolve();

    const durationMs =
      this.trackDurationMs > 0 ? this.trackDurationMs : this.playedDurationMs;
    const rawRate =
      durationMs > 0
        ? this.playedDurationMs / durationMs
        : this.completed
          ? 1.0
          : 0.0;
    const completionRate = Math.min(1.0, Math.max(0.0, rawRate));
    const isSkipped = !this.completed && this.playedDurationMs < 30000;

    if (this.playedDurationMs >= 3000 || this.completed) {
      const snap = this.activeTrack;
      const artistsList = snap?.artistList?.length
        ? snap.artistList.map((a) => ({ id: a.id || "unknown", name: a.name }))
        : snap?.artists
          ? snap.artists
              .split(",")
              .map((name) => ({
                id: snap?.artistId || "unknown",
                name: name.trim(),
              }))
          : [{ id: "unknown", name: "Unknown Artist" }];

      reported = this.sendEvent({
        playbackSessionId: this.playbackSessionId,
        listeningSessionId: this.getOrCreateListeningSession(),
        trackId: this.activeTrackId,
        trackSnapshot: snap
          ? {
              id: snap.id,
              title: snap.title || "Unknown Track",
              artists: artistsList,
              album: snap.album
                ? { id: snap.album.id || "", title: snap.album.title || "" }
                : undefined,
              cover: snap.coverUrl
                ? { url: snap.coverUrl, width: 512, height: 512 }
                : undefined,
              durationMs: snap.durationMs || this.trackDurationMs,
            }
          : undefined,
        playedDurationMs: Math.round(this.playedDurationMs),
        trackDurationMs:
          this.trackDurationMs > 0 ? this.trackDurationMs : undefined,
        completionRate: Number(completionRate.toFixed(4)),
        completed: this.completed,
        skipped: isSkipped,
        loopCount: this.loopCount,
        hasSeekBackward: this.hasSeekBackward,
        context: this.context,
      });
    }

    this.activeTrackId = null;
    this.activeTrack = null;
    this.playbackSessionId = "";
    this.lastTickTime = null;
    this.playedDurationMs = 0;
    this.completed = false;
    this.loopCount = 0;
    this.hasSeekBackward = false;
    return reported;
  }

  private sendEvent(payload: RecordPlaybackEventRequest): Promise<void> {
    return api.recordPlaybackEvent(payload).then(() => undefined, (err) => {
      log(
        "yellow",
        "telemetry",
        `playback event report failed: ${err instanceof Error ? err.message : String(err)}`,
      );
    });
  }
}

class PlayerEngine {
  private sessionId = 0;
  private lyricsLoadToken = 0;
  private lyricsAbort: AbortController | null = null;
  private currentLyricsTrackId: string | null = null;
  private masterPlaylist: Track[] = [];
  private originalUpcomingQueue: Track[] = [];
  private telemetry = new PlaybackTelemetryTracker();
  private radioAppendTimeout: ReturnType<typeof setTimeout> | null = null;
  private radioWaveId: string | null = null;
  // single in-flight similar-tracks request, so a refill and an end-of-queue wait share it
  private radioFetchInFlight: Promise<void> | null = null;
  private consecutiveAutoSkips = 0;
  private lastPreloadKey: string | null = null;
  private inFlightLyricsPrefetches = new Map<string, Promise<void>>();

  constructor() {
    usePlayerStore.setState({
      dispatch: this.dispatch.bind(this),
    });

    if (playerRuntime) {
      playerRuntime.onEnded = () => {
        const isRepeatOne = usePlayerStore.getState().repeat === "one";
        this.telemetry.onTrackCompleted(isRepeatOne);
      };
      playerRuntime.onError = (info) => this.handlePlaybackError(info);
    }

    if (typeof window !== "undefined") {
      const g = window as any;
      if (g.__playerEngineUnsub) {
        g.__playerEngineUnsub();
      }

      window.addEventListener("beforeunload", () => {
        this.telemetry.flushCurrentTrack();
      });

      let prevTrackId: string | null =
        usePlayerStore.getState().currentTrack?.id || null;
      let prevStatus: string = "idle";
      let newTrack = false;
      const unsub = usePlayerStore.subscribe((state) => {
        const trackId = state.currentTrack?.id || null;
        if (trackId !== prevTrackId) {
          prevTrackId = trackId;
          newTrack = true;
          this.lastPreloadKey = null;
          if (state.currentTrack) {
            this.telemetry.startTrack(
              state.currentTrack,
              state.playbackContext,
            );
          } else {
            this.telemetry.flushCurrentTrack();
          }
          void this.fetchLyricsForTrack(state.currentTrack);
          this.preloadNextTrack(state);
        }

        if (state.status === "playing") {
          this.telemetry.onTick(true);
        } else {
          this.telemetry.onTick(false);
        }

        if (state.status !== prevStatus || newTrack) {
          if (state.status === "playing") {
            this.telemetry.onPlaying();
            this.consecutiveAutoSkips = 0;
          } else if (state.status === "paused" || state.status === "idle") {
            this.telemetry.onPausedOrStopped();
          }
          prevStatus = state.status;
          void this.syncDiscordPresence(state, newTrack);
          newTrack = false;
        }
      });

      g.__playerEngineUnsub = unsub;

      const restoreLyricsForHydratedTrack = () => {
        const state = usePlayerStore.getState();
        const restoredTrack = state.currentTrack;
        if (restoredTrack) {
          prevTrackId = restoredTrack.id;
          void this.fetchLyricsForTrack(restoredTrack);
          this.preloadNextTrack(state);
        }
      };

      if (usePlayerStore.persist.hasHydrated()) {
        restoreLyricsForHydratedTrack();
      } else {
        usePlayerStore.persist.onFinishHydration(restoreLyricsForHydratedTrack);
      }
    }
  }

  public subscribe(listener: () => void): () => void {
    return usePlayerStore.subscribe(listener);
  }

  public getSnapshot(): PlayerState {
    return usePlayerStore.getState();
  }

  public primeUserGesture(): void {
    // Intentionally a no-op placeholder for gesture priming
  }

  public dispatch(command: PlayerCommand): void {
    switch (command.type) {
      case "PLAY_REQUESTED":
        void this.playTrack(
          command.track,
          command.queue,
          command.context,
          command.contextCover,
        );
        break;
      case "PAUSE_REQUESTED":
        this.pause();
        break;
      case "RESUME_REQUESTED":
        this.resume();
        break;
      case "SEEK_COMMITTED":
        this.seek(command.positionMs);
        break;
      case "SKIP_NEXT":
        void this.skipNext(command.isAutoEnd);
        break;
      case "SKIP_PREVIOUS":
        void this.skipPrevious();
        break;
      case "SET_VOLUME":
        this.setVolume(command.volume);
        break;
      case "SET_PLAYBACK_RATE":
        this.setPlaybackRate(command.rate);
        break;
      case "SET_PITCH_SEMITONES":
        this.setPitchSemitones(command.semitones);
        break;
      case "TOGGLE_PLAY_PAUSE":
        this.togglePlayPause();
        break;
    }
  }

  public async playTrack(
    track: Track,
    queue?: Track[],
    context?: string | null,
    contextCover?: string | null,
    queueIndex?: number,
    preserveQueue?: boolean,
  ): Promise<void> {
    const store = usePlayerStore.getState();
    const nextQueue = this.normalizeQueue(queue ?? [track], track);
    const nextIndex =
      queueIndex !== undefined
        ? queueIndex
        : Math.max(
            0,
            nextQueue.findIndex((item) => item.id === track.id),
          );

    this.sessionId += 1;
    const mySession = this.sessionId;
    this.radioWaveId = newRadioWaveId();

    if (context !== undefined) {
      store.setPlaybackContext(context);
    }
    if (contextCover !== undefined) {
      store.setPlaybackContextCover(contextCover);
    }
    let finalQueue = nextQueue;
    let finalIndex = nextIndex;

    const isSelectingFromCurrentQueue =
      preserveQueue === true ||
      (queueIndex !== undefined &&
        store.queue.length > 0 &&
        store.queue.length === nextQueue.length &&
        store.queue[queueIndex]?.id === track.id);

    if (!isSelectingFromCurrentQueue) {
      this.masterPlaylist = [...nextQueue];
    }

    if (!isSelectingFromCurrentQueue && store.shuffle && nextQueue.length > 1) {
      const played = nextQueue.slice(0, nextIndex);
      const selectedTrackItem = nextQueue[nextIndex] ?? track;
      const upcoming = nextQueue.slice(nextIndex + 1);

      this.originalUpcomingQueue = [...upcoming];
      const shuffledUpcoming = shuffleArray(upcoming);

      finalQueue = [...played, selectedTrackItem, ...shuffledUpcoming];
      finalIndex = nextIndex;
    } else if (!isSelectingFromCurrentQueue) {
      this.originalUpcomingQueue = [];
    }

    store.setQueue(finalQueue);

    const selectedTrack = finalQueue[finalIndex] ?? track;
    store.setCurrentTrack(selectedTrack, finalIndex);
    store.setPosition(0);
    store.setDuration(selectedTrack.durationMs ?? 0);
    store.setStatus("loading", null);

    if (playerRuntime) {
      void playerRuntime.loadAndPlay(selectedTrack);
    }

    this.maybeExtendQueue(
      mySession,
      selectedTrack.id,
      finalIndex,
      finalQueue.length,
    );
  }

  public async playShuffled(
    tracks: Track[],
    context?: string | null,
    contextCover?: string | null,
    startIndex?: number,
  ): Promise<void> {
    if (!tracks || tracks.length === 0) return;
    const store = usePlayerStore.getState();
    const seedIndex =
      startIndex !== undefined && startIndex >= 0 && startIndex < tracks.length
        ? startIndex
        : Math.floor(Math.random() * tracks.length);
    const seedTrack = tracks[seedIndex];
    const remaining = [
      ...tracks.slice(0, seedIndex),
      ...tracks.slice(seedIndex + 1),
    ];
    const shuffledRemaining = shuffleArray(remaining);
    const finalQueue = [seedTrack, ...shuffledRemaining];

    this.masterPlaylist = [...tracks];
    this.originalUpcomingQueue = [...remaining];

    store.setShuffle(true);
    if (context !== undefined) {
      store.setPlaybackContext(context);
    }
    if (contextCover !== undefined) {
      store.setPlaybackContextCover(contextCover);
    }

    this.sessionId += 1;
    const mySession = this.sessionId;
    this.radioWaveId = newRadioWaveId();

    store.setQueue(finalQueue);
    store.setCurrentTrack(seedTrack, 0);
    store.setPosition(0);
    store.setDuration(seedTrack.durationMs ?? 0);
    store.setStatus("loading", null);

    if (playerRuntime) {
      void playerRuntime.loadAndPlay(seedTrack);
    }

    this.maybeExtendQueue(mySession, seedTrack.id, 0, finalQueue.length);
  }

  public async startRadioStation(track: Track): Promise<void> {
    const store = usePlayerStore.getState();
    this.sessionId += 1;
    const mySession = this.sessionId;
    // new station, new wave instance
    this.radioWaveId = newRadioWaveId();
    const waveId = this.radioWaveId;

    store.setPlaybackContext(`radio:${track.id}`);
    // a station never loops back to its first track
    if (store.repeat === "all") store.setRepeat("off");
    store.setPlaybackContextCover(track.coverUrl ?? null);
    store.setQueue([track]);
    this.originalUpcomingQueue = [];

    store.setCurrentTrack(track, 0);
    store.setPosition(0);
    store.setDuration(track.durationMs ?? 0);
    store.setStatus("loading", null);

    if (playerRuntime) {
      void playerRuntime.loadAndPlay(track);
    }

    try {
      const response = await api.getRadio(track.id, { k: 20, wave_id: waveId });
      if (mySession !== this.sessionId) return;
      const additions = response.items
        .map(toClientTrack)
        .filter((item) => item.id !== track.id);

      if (additions.length > 0) {
        const latestStore = usePlayerStore.getState();
        const updatedQueue = [track, ...additions];
        latestStore.setQueue(updatedQueue);
        if (latestStore.shuffle) {
          const upcoming = additions;
          this.originalUpcomingQueue = [...upcoming];
          const shuffledUpcoming = shuffleArray(upcoming);
          latestStore.setQueue([track, ...shuffledUpcoming]);
        }
        const sample = additions
          .slice(0, 3)
          .map((t) => `"${t.title}" by ${t.artists || "Unknown"}`)
          .join(", ");
        log(
          "green",
          "radio",
          `started station for "${track.title}" with ${additions.length} tracks from Radio Wave engine: [${sample}]`,
        );
      }
    } catch (error) {
      log(
        "yellow",
        "radio",
        `radio fetch failed: ${error instanceof Error ? error.message : String(error)}`,
      );
    }
  }

  public pause(): void {
    const store = usePlayerStore.getState();
    const wasLoading = store.status === "loading";
    if (wasLoading) {
      playerRuntime?.cancelPendingLoad();
    }
    const audioEl = document.getElementById(
      "liner-audio",
    ) as HTMLAudioElement | null;
    if (audioEl && !Number.isNaN(audioEl.currentTime)) {
      store.setPosition(Math.round(audioEl.currentTime * 1000));
    }
    store.setStatus("paused");
    if (playerRuntime && !wasLoading) {
      playerRuntime.pause();
    }
  }

  public resume(): void {
    const store = usePlayerStore.getState();
    if (playerRuntime) {
      if (
        store.currentTrack &&
        !playerRuntime.hasLoadedSourceFor(store.currentTrack.id)
      ) {
        void playerRuntime.loadAndPlay(store.currentTrack, store.positionMs);
      } else {
        store.setStatus("playing");
        playerRuntime.resume();
      }
    }
  }

  public togglePlayPause(): void {
    const store = usePlayerStore.getState();
    if (store.status === "playing" || store.status === "loading") {
      this.pause();
    } else {
      this.resume();
    }
  }

  public async skipNext(isAutoEnd: boolean = false): Promise<void> {
    const store = usePlayerStore.getState();
    const nextIndex = this.computeNextIndex(isAutoEnd);

    if (
      nextIndex === null &&
      isRadioContext(store.playbackContext) &&
      store.currentTrack
    ) {
      // radio ran dry (refill not back yet / failed earlier): fetch now and carry on
      const lengthBefore = store.queue.length;
      const waitSession = this.sessionId;
      store.setStatus("loading", null);
      if (this.radioAppendTimeout) {
        clearTimeout(this.radioAppendTimeout);
        this.radioAppendTimeout = null;
      }
      await this.appendSimilarTracksForSeed(waitSession, store.currentTrack.id);
      if (waitSession !== this.sessionId) return;
      if (usePlayerStore.getState().queue.length > lengthBefore) {
        await this.skipNext(isAutoEnd);
        return;
      }
    }

    if (nextIndex === null) {
      this.stopPlayback();
      store.setStatus("idle");
      store.setPosition(0);
      store.setDuration(0);
      store.setCurrentTrack(null, -1);
      store.setFullscreen(false);
      return;
    }

    this.sessionId += 1;
    const mySession = this.sessionId;
    const nextTrack = store.queue[nextIndex];
    if (nextTrack) {
      // Optimistic synchronous UI update
      store.setCurrentTrack(nextTrack, nextIndex);
      store.setPosition(0);
      store.setDuration(nextTrack.durationMs ?? 0);
      store.setStatus("loading", null);

      if (playerRuntime) {
        void playerRuntime.loadAndPlay(nextTrack);
      }
      this.maybeExtendQueue(
        mySession,
        nextTrack.id,
        nextIndex,
        store.queue.length,
      );
    }
  }

  public async skipPrevious(): Promise<void> {
    const store = usePlayerStore.getState();
    if (store.queue.length === 0) return;

    // If playback is > 3 seconds, standard player behavior restarts the track
    if (store.positionMs > 3000) {
      this.seek(0);
      return;
    }

    const prevIndex =
      store.currentIndex > 0
        ? store.currentIndex - 1
        : store.repeat === "all" && !isRadioContext(store.playbackContext)
          ? store.queue.length - 1
          : 0;

    this.sessionId += 1;
    const mySession = this.sessionId;
    const prevTrack = store.queue[prevIndex];
    if (prevTrack) {
      // Optimistic synchronous UI update
      store.setCurrentTrack(prevTrack, prevIndex);
      store.setPosition(0);
      store.setDuration(prevTrack.durationMs ?? 0);
      store.setStatus("loading", null);

      if (playerRuntime) {
        void playerRuntime.loadAndPlay(prevTrack);
      }
      this.maybeExtendQueue(
        mySession,
        prevTrack.id,
        prevIndex,
        store.queue.length,
      );
    }
  }

  public setVolume(volume: number): void {
    usePlayerStore.getState().setVolume(Math.min(1, Math.max(0, volume)));
  }

  public setVolumeSmooth(volume: number): void {
    this.setVolume(volume);
  }

  public setPlaybackRate(rate: number): void {
    pitchShifter.resumeContext();
    const clampedRate = Math.min(2.0, Math.max(0.5, Number(rate.toFixed(2))));
    const store = usePlayerStore.getState();
    if (store.isPitchLinked) {
      const semitones = Number((12 * Math.log2(clampedRate)).toFixed(1));
      store.setPitchSemitones(semitones);
    }
    store.setPlaybackRate(clampedRate);
  }

  public setPitchSemitones(semitones: number): void {
    pitchShifter.resumeContext();
    const clampedSemitones = Math.min(
      12,
      Math.max(-12, Number(semitones.toFixed(1))),
    );
    const store = usePlayerStore.getState();
    if (store.isPitchLinked) {
      const rate = Number(Math.pow(2, clampedSemitones / 12).toFixed(2));
      const clampedRate = Math.min(2.0, Math.max(0.5, rate));
      store.setPlaybackRate(clampedRate);
    }
    store.setPitchSemitones(clampedSemitones);
  }

  public setIsPitchLinked(linked: boolean): void {
    pitchShifter.resumeContext();
    const store = usePlayerStore.getState();
    store.setIsPitchLinked(linked);
    if (linked) {
      const rate = store.playbackRate ?? 1;
      const semitones = Number((12 * Math.log2(rate)).toFixed(1));
      store.setPitchSemitones(semitones);
    }
  }

  public setKeepSpeedAcrossTracks(keep: boolean): void {
    usePlayerStore.getState().setKeepSpeedAcrossTracks(keep);
  }

  public setIsReverbEnabled(enabled: boolean): void {
    pitchShifter.resumeContext();
    usePlayerStore.getState().setIsReverbEnabled(enabled);
  }

  public setReverbLevel(level: number): void {
    pitchShifter.resumeContext();
    usePlayerStore.getState().setReverbLevel(level);
  }

  public resetSpeedAndPitch(): void {
    usePlayerStore.getState().resetSpeedAndPitch();
  }

  public setRepeat(mode: RepeatMode): void {
    usePlayerStore.getState().setRepeat(mode);
  }

  public setShuffle(enabled: boolean): void {
    const store = usePlayerStore.getState();
    if (store.shuffle === enabled) return;
    store.setShuffle(enabled);

    const { queue, currentIndex } = store;
    if (queue.length > 0 && currentIndex >= 0) {
      const played = queue.slice(0, currentIndex);
      const current = queue[currentIndex];
      const upcoming = queue.slice(currentIndex + 1);

      if (enabled) {
        this.originalUpcomingQueue = [...upcoming];
        const shuffledUpcoming = shuffleArray(upcoming);
        store.setQueue([...played, current, ...shuffledUpcoming]);
      } else {
        const referenceList =
          this.masterPlaylist.length > 0
            ? this.masterPlaylist
            : this.originalUpcomingQueue;
        const unshuffledUpcoming = restoreOriginalRelativeOrder(
          upcoming,
          referenceList,
        );
        store.setQueue([...played, current, ...unshuffledUpcoming]);
        this.originalUpcomingQueue = [];
      }
    }
  }

  public seek(positionMs: number, autoPlay: boolean = false): void {
    const store = usePlayerStore.getState();
    const currentMs = store.positionMs;
    const durationMs = store.durationMs || store.currentTrack?.durationMs || 0;
    const nextMs = Math.round(
      Math.max(0, Math.min(durationMs || positionMs, positionMs)),
    );

    if (nextMs < currentMs - 3000) {
      this.telemetry.recordSeekBackward();
    }

    store.setPosition(nextMs);
    if (playerRuntime) {
      if (
        store.currentTrack &&
        !playerRuntime.hasLoadedSourceFor(store.currentTrack.id)
      ) {
        if (
          playerRuntime.getCurrentTrackId() === store.currentTrack.id &&
          store.status === "loading"
        ) {
          playerRuntime.setPendingSeek(nextMs);
          return;
        }
        if (autoPlay || store.status === "playing") {
          void playerRuntime.loadAndPlay(store.currentTrack, nextMs);
        }
        return;
      }
      playerRuntime.seek(nextMs);
      if (autoPlay && store.status !== "playing") {
        this.resume();
      }
    }
  }

  public seekAndPlay(positionMs: number): void {
    this.seek(positionMs, true);
  }

  public addToQueue(track: Track): void {
    const store = usePlayerStore.getState();
    const newQueue = [...store.queue, track];
    store.setQueue(newQueue);
    if (this.masterPlaylist.length > 0) {
      this.masterPlaylist.push(track);
    }
    if (store.shuffle) {
      this.originalUpcomingQueue.push(track);
    }
    this.preloadNextTrack(store);
  }

  public playNext(track: Track): void {
    const store = usePlayerStore.getState();
    const currentQueue = store.queue;
    const currentIndex = store.currentIndex;

    if (currentQueue.length === 0) {
      void this.playTrack(track, [track]);
      return;
    }

    const nextQueue = [
      ...currentQueue.slice(0, currentIndex + 1),
      track,
      ...currentQueue.slice(currentIndex + 1),
    ];
    store.setQueue(nextQueue);
    if (this.masterPlaylist.length > 0) {
      const currentTrack = store.currentTrack;
      const masterIdx = currentTrack
        ? this.masterPlaylist.findIndex((t) => t.id === currentTrack.id)
        : -1;
      if (masterIdx >= 0) {
        this.masterPlaylist.splice(masterIdx + 1, 0, track);
      } else {
        this.masterPlaylist.push(track);
      }
    }
    if (store.shuffle) {
      this.originalUpcomingQueue.unshift(track);
    }
    this.preloadNextTrack(store);
  }

  public async stopAndClear(): Promise<void> {
    const reported = this.telemetry.flushCurrentTrack();
    if (this.radioAppendTimeout) {
      clearTimeout(this.radioAppendTimeout);
      this.radioAppendTimeout = null;
    }
    this.radioFetchInFlight = null;
    this.radioWaveId = null;
    this.lyricsAbort?.abort();
    this.lyricsAbort = null;
    this.lyricsLoadToken += 1;
    this.currentLyricsTrackId = null;
    this.masterPlaylist = [];
    this.originalUpcomingQueue = [];
    this.lastPreloadKey = null;
    this.consecutiveAutoSkips = 0;
    playerRuntime?.stop();
    usePlayerStore.getState().resetPlayback();
    useLyricsStore.getState().reset();
    debouncedStorage.flush();
    await reported;
  }

  public clearQueue(): void {
    usePlayerStore.getState().clearQueue();
    this.masterPlaylist = [];
    this.originalUpcomingQueue = [];
  }

  public reorderQueue(fromIndex: number, toIndex: number): void {
    const store = usePlayerStore.getState();
    const queue = [...store.queue];
    if (
      fromIndex < 0 ||
      fromIndex >= queue.length ||
      toIndex < 0 ||
      toIndex >= queue.length ||
      fromIndex === toIndex
    ) {
      return;
    }

    const [movedItem] = queue.splice(fromIndex, 1);
    queue.splice(toIndex, 0, movedItem);

    let newCurrentIndex = store.currentIndex;
    if (store.currentIndex === fromIndex) {
      newCurrentIndex = toIndex;
    } else if (
      fromIndex < store.currentIndex &&
      toIndex >= store.currentIndex
    ) {
      newCurrentIndex -= 1;
    } else if (
      fromIndex > store.currentIndex &&
      toIndex <= store.currentIndex
    ) {
      newCurrentIndex += 1;
    }

    store.setQueue(queue);
    if (newCurrentIndex !== store.currentIndex) {
      store.setCurrentTrack(store.currentTrack, newCurrentIndex);
    }
    this.preloadNextTrack(store);
  }

  public snapshotQueue(): Track[] {
    return [...usePlayerStore.getState().queue];
  }

  private stopPlayback(): void {
    if (playerRuntime) {
      playerRuntime.pause();
    }
  }

  private normalizeQueue(queue: Track[], selected: Track): Track[] {
    if (queue.length === 0) return [selected];
    return queue.map((item) => ({
      ...item,
      coverUrl: item.coverUrl || selected.coverUrl,
      durationMs: item.durationMs ?? 0,
    }));
  }

  private handlePlaybackError(info: {
    trackId: string;
    message: string;
  }): void {
    const store = usePlayerStore.getState();
    if (!store.currentTrack || store.currentTrack.id !== info.trackId) return;

    const track = store.currentTrack;
    const translate = createTranslatorSync(getStoredLocale());
    this.consecutiveAutoSkips += 1;

    if (this.consecutiveAutoSkips > MAX_CONSECUTIVE_AUTO_SKIPS) {
      log(
        "red",
        "playback",
        `${this.consecutiveAutoSkips} consecutive tracks failed to play — stopping instead of skipping further`,
      );
      showToast(translate("player.playback_stopped_too_many_errors"), "error");
      this.consecutiveAutoSkips = 0;
      this.stopPlayback();
      store.setStatus("idle");
      store.setPosition(0);
      store.setDuration(0);
      store.setCurrentTrack(null, -1);
      return;
    }

    console.error("[PlaybackError]", info.trackId, info.message);
    log(
      "yellow",
      "playback",
      `"${track.title}" failed (${info.message}) — skipping to next`,
    );
    showToast(translate("player.track_unavailable_title"), "error", {
      description: track.artists
        ? `${track.title} — ${track.artists}`
        : track.title,
    });
    void this.skipNext(false);
  }

  private computeNextIndex(isAutoEnd: boolean = false): number | null {
    const store = usePlayerStore.getState();
    const queueSize = store.queue.length;
    if (queueSize === 0 || store.currentIndex < 0) return null;
    if (isAutoEnd && store.repeat === "one") return store.currentIndex;

    if (store.currentIndex + 1 < queueSize) return store.currentIndex + 1;
    // radio never wraps to its first track; skipNext refills it instead
    if (isRadioContext(store.playbackContext)) return null;
    if (store.repeat === "all" || store.repeat === "one") return 0;
    return null;
  }

  /** queue refill trigger: radio refills early (one track left), autoplay-similar on the last track */
  private maybeExtendQueue(
    session: number,
    seedTrackId: string,
    index: number,
    queueLength: number,
  ): void {
    const radio = isRadioContext(usePlayerStore.getState().playbackContext);
    const due = radio
      ? shouldRefillRadio(queueLength, index)
      : index === queueLength - 1;
    if (due) this.scheduleAppendSimilarTracks(session, seedTrackId);
  }

  private scheduleAppendSimilarTracks(
    session: number,
    seedTrackId: string,
  ): void {
    if (this.radioAppendTimeout) {
      clearTimeout(this.radioAppendTimeout);
      this.radioAppendTimeout = null;
    }

    this.radioAppendTimeout = setTimeout(() => {
      void this.appendSimilarTracksForSeed(session, seedTrackId);
    }, 400);
  }

  private appendSimilarTracksForSeed(
    session: number,
    seedTrackId: string,
  ): Promise<void> {
    if (this.radioFetchInFlight) return this.radioFetchInFlight;
    const run = this.fetchAndAppendSimilarTracks(session, seedTrackId).finally(
      () => {
        if (this.radioFetchInFlight === run) this.radioFetchInFlight = null;
      },
    );
    this.radioFetchInFlight = run;
    return run;
  }

  private async fetchAndAppendSimilarTracks(
    session: number,
    seedTrackId: string,
  ): Promise<void> {
    const currentState = usePlayerStore.getState();
    // radio always continues; plain lists only when "autoplay similar" is on
    const radio = isRadioContext(currentState.playbackContext);
    if (!radio && !currentState.autoplaySimilar) return;
    const startContext = currentState.playbackContext;

    const historyIds = currentState.queue.map((track) => track.id);
    // keep paginating the same wave instance across queue generations
    if (!this.radioWaveId) this.radioWaveId = newRadioWaveId();
    const waveId = this.radioWaveId;

    let items: ApiRadioTrack[];
    try {
      const response = await api.getRadio(seedTrackId, {
        history: historyIds.slice(-20),
        k: 20,
        wave_id: waveId,
      });
      items = response.items;
    } catch (error) {
      log(
        "yellow",
        "radio",
        `similar tracks fetch failed: ${error instanceof Error ? error.message : String(error)}`,
      );
      return;
    }

    const state = usePlayerStore.getState();
    // radio: still valid while the same station plays (skipping within it is fine);
    // anything else: only for the exact track session that asked
    if (
      radio
        ? state.playbackContext !== startContext
        : session !== this.sessionId
    )
      return;
    if (!radio && !state.autoplaySimilar) return;

    const queuedIds = new Set(state.queue.map((track) => track.id));
    const additions = items
      .map(toClientTrack)
      .filter((track) => !queuedIds.has(track.id));
    if (additions.length === 0) return;

    const sample = additions
      .slice(0, 3)
      .map((t) => `"${t.title}" by ${t.artists || "Unknown"}`)
      .join(", ");
    log(
      "green",
      "radio",
      `appending ${additions.length} tracks from Radio Wave engine (wave=${waveId.slice(0, 8)} history=${historyIds.length}): [${sample}]`,
    );
    state.setQueue([...state.queue, ...additions]);
    this.preloadNextTrack(state);
  }

  private async syncDiscordPresence(
    _state: PlayerState,
    _trackChanged: boolean = false,
  ): Promise<void> {}

  private preloadNextTrack(state: PlayerState): void {
    const queue = state.queue;
    const currentIndex = state.currentIndex;
    let nextTrack: Track | null = null;
    if (currentIndex >= 0 && currentIndex < queue.length - 1) {
      nextTrack = queue[currentIndex + 1];
    } else if (
      state.repeat === "all" &&
      queue.length > 0 &&
      !isRadioContext(state.playbackContext)
    ) {
      nextTrack = queue[0];
    }

    if (!nextTrack) {
      this.lastPreloadKey = null;
      return;
    }

    const currentId = state.currentTrack?.id || "none";
    const preloadKey = `${currentId}->${nextTrack.id}`;
    if (this.lastPreloadKey === preloadKey) {
      return;
    }
    this.lastPreloadKey = preloadKey;

    if (nextTrack.coverUrl) {
      void preloadCoverArt(nextTrack.coverUrl);
    }

    if (!lyricsCache.has(nextTrack.id)) {
      void this.prefetchLyrics(nextTrack.id, lyricsHint(nextTrack));
    }

    void linerDb.putTrack(nextTrack);

    if (playerRuntime) {
      void playerRuntime.preloadTrack(nextTrack);
    }
  }

  private async prefetchLyrics(
    trackId: string,
    hint?: LyricsHint,
  ): Promise<void> {
    if (!trackId) return;

    if (lyricsCache.has(trackId)) return;
    if (this.inFlightLyricsPrefetches.has(trackId)) {
      return this.inFlightLyricsPrefetches.get(trackId);
    }

    const prefetchPromise = (async () => {
      try {
        const existing = await linerDb.getLyrics(trackId);
        if (existing) {
          const lastChecked = existing.lastCheckedAt || 0;
          if (Date.now() - lastChecked < SEVEN_DAYS_MS) {
            return;
          }
        }

        let bestCandidate: LyricsCandidate | null = null;
        const providers: {
          provider: string;
          syncLevel: LyricsSyncLevel;
          quality: number;
          candidate: LyricsCandidate;
        }[] = [];
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 8000);
        for await (const event of api.streamLyrics(
          trackId,
          controller.signal,
          hint,
        )) {
          if (event.type === "provider" && event.status === "found") {
            const candidate = event.candidate;
            if (shouldCacheLyricsCandidate(candidate)) {
              lyricsCache.setProvider(trackId, candidate);
            }
            providers.push({
              provider: candidate.provider,
              syncLevel: candidate.syncLevel,
              quality: candidate.quality.total,
              candidate,
            });
            if (
              !bestCandidate ||
              isBetterLyricsCandidate(candidate, bestCandidate)
            ) {
              bestCandidate = candidate;
            }
          } else if (event.type === "done") {
            break;
          }
        }
        clearTimeout(timeout);

        if (bestCandidate && shouldCacheLyricsCandidate(bestCandidate)) {
          lyricsCache.set(trackId, bestCandidate, providers);
          void linerDb.putLyrics({
            trackId,
            syncLevel: bestCandidate.syncLevel,
            quality: bestCandidate.quality.total,
            activeProvider: bestCandidate.provider,
            availableProviders: providers,
            rawLyrics: bestCandidate.lyrics.content,
            rawFormat: bestCandidate.lyrics.format,
            candidate: bestCandidate,
            lastCheckedAt: Date.now(),
            updatedAt: Date.now(),
          });
        }
      } catch {
      } finally {
        this.inFlightLyricsPrefetches.delete(trackId);
      }
    })();

    this.inFlightLyricsPrefetches.set(trackId, prefetchPromise);
    return prefetchPromise;
  }

  private async fetchLyricsForTrack(track: Track | null): Promise<void> {
    const lyricsStore = useLyricsStore.getState();

    if (!track) {
      this.currentLyricsTrackId = null;
      lyricsStore.reset();
      return;
    }

    const trackId = track.id;
    if (
      this.currentLyricsTrackId === trackId &&
      lyricsStore.currentLyricsTrackId === trackId
    ) {
      return;
    }

    this.currentLyricsTrackId = trackId;
    const token = ++this.lyricsLoadToken;
    this.lyricsAbort?.abort();
    const controller = new AbortController();
    this.lyricsAbort = controller;
    let bestCandidate: LyricsCandidate | null = null;

    const memoryCached = lyricsCache.get(trackId);
    let cached: CachedLyricsItem | CachedLyricsRecord | null =
      memoryCached || null;
    if (!cached) {
      try {
        cached = await linerDb.getLyrics(trackId);
      } catch {
        cached = null;
      }
    }

    if (cached && cached.candidate) {
      bestCandidate = cached.candidate;
      const parsed = parseRawLyrics(
        cached.candidate.lyrics.content,
        cached.candidate.lyrics.format,
      );
      lyricsStore.setLyricsState({
        lyricsLoading: false,
        lyricsError: null,
        rawLyrics: cached.candidate.lyrics.content,
        rawFormat: cached.candidate.lyrics.format,
        braccatoLyrics: parsed.braccatoLyrics,
        syncedLines: parsed.syncedLines,
        plainLyrics: parsed.plainLyrics,
        lyricsQuality: cached.candidate.quality.total,
        currentLyricsTrackId: trackId,
        activeProvider: cached.candidate.provider,
        availableProviders: cached.availableProviders || [
          {
            provider: cached.candidate.provider,
            syncLevel: cached.candidate.syncLevel,
            quality: cached.candidate.quality.total,
            candidate: cached.candidate,
          },
        ],
      });

      const lastChecked =
        (cached as any).lastCheckedAt || (cached as any).timestamp || 0;
      log(
        "cyan",
        "lyrics",
        `cache hit for "${track.title}" (age: ${Math.round((Date.now() - lastChecked) / 1000)}s)`,
      );
      const isStale = Date.now() - lastChecked >= SEVEN_DAYS_MS;
      if (!isStale || (cached as any).userLocked) {
        return;
      }

      void linerDb.updateLyricsChecked(trackId);
    } else {
      lyricsStore.setLyricsState({
        lyricsLoading: true,
        lyricsError: null,
        rawLyrics: null,
        rawFormat: null,
        braccatoLyrics: [],
        syncedLines: [],
        plainLyrics: null,
        lyricsQuality: 0,
        currentLyricsTrackId: trackId,
        activeProvider: null,
        availableProviders: [],
      });
    }

    if (this.inFlightLyricsPrefetches.has(trackId)) {
      try {
        await this.inFlightLyricsPrefetches.get(trackId);
        if (token !== this.lyricsLoadToken || controller.signal.aborted) return;
        const freshCached =
          lyricsCache.get(trackId) || (await linerDb.getLyrics(trackId));
        if (freshCached && freshCached.candidate) {
          const parsed = parseRawLyrics(
            freshCached.candidate.lyrics.content,
            freshCached.candidate.lyrics.format,
          );
          lyricsStore.setLyricsState({
            lyricsLoading: false,
            lyricsError: null,
            rawLyrics: freshCached.candidate.lyrics.content,
            rawFormat: freshCached.candidate.lyrics.format,
            braccatoLyrics: parsed.braccatoLyrics,
            syncedLines: parsed.syncedLines,
            plainLyrics: parsed.plainLyrics,
            lyricsQuality: freshCached.candidate.quality.total,
            currentLyricsTrackId: trackId,
            activeProvider: freshCached.candidate.provider,
            availableProviders: freshCached.availableProviders || [],
          });
          return;
        }
      } catch {}
    }

    log("cyan", "lyrics", `fetching for "${track.title}"`);

    try {
      for await (const event of api.streamLyrics(
        trackId,
        controller.signal,
        lyricsHint(track),
      )) {
        if (token !== this.lyricsLoadToken || controller.signal.aborted) break;

        if (event.type === "provider" && event.status === "found") {
          const candidate = event.candidate;
          const currentStore = useLyricsStore.getState();
          const option = {
            provider: candidate.provider,
            syncLevel: candidate.syncLevel,
            quality: candidate.quality.total,
            candidate,
          };
          const updatedProviders = [
            ...currentStore.availableProviders.filter(
              (p) => p.provider !== candidate.provider,
            ),
            option,
          ].sort((a, b) => compareLyricsCandidates(a.candidate, b.candidate));

          // cache provider individually if it satisfies provider rules
          if (shouldCacheLyricsCandidate(candidate)) {
            lyricsCache.setProvider(trackId, candidate);
          }

          if (
            !bestCandidate ||
            isBetterLyricsCandidate(candidate, bestCandidate)
          ) {
            bestCandidate = candidate;

            const parsed = parseRawLyrics(
              candidate.lyrics.content,
              candidate.lyrics.format,
            );
            if (token !== this.lyricsLoadToken || controller.signal.aborted)
              break;

            useLyricsStore.getState().setLyricsState({
              activeProvider: candidate.provider,
              availableProviders: updatedProviders,
              rawLyrics: candidate.lyrics.content,
              rawFormat: candidate.lyrics.format,
              braccatoLyrics: parsed.braccatoLyrics,
              syncedLines: parsed.syncedLines,
              plainLyrics: parsed.plainLyrics,
              lyricsQuality: candidate.quality.total,
            });
            if (shouldCacheLyricsCandidate(candidate)) {
              lyricsCache.set(trackId, candidate, updatedProviders);
              void linerDb.putLyrics({
                trackId,
                syncLevel: candidate.syncLevel,
                quality: candidate.quality.total,
                activeProvider: candidate.provider,
                availableProviders: updatedProviders,
                rawLyrics: candidate.lyrics.content,
                rawFormat: candidate.lyrics.format,
                candidate,
                lastCheckedAt: Date.now(),
                updatedAt: Date.now(),
              });
            }
            log(
              "green",
              "lyrics",
              `candidate ${candidate.provider} q=${candidate.quality.total} sync=${candidate.syncLevel}`,
            );
          } else {
            useLyricsStore.getState().setLyricsState({
              availableProviders: updatedProviders,
            });
            log(
              "yellow",
              "lyrics",
              `skip worse candidate ${candidate.provider} q=${candidate.quality.total}`,
            );
          }
        } else if (event.type === "provider" && event.status === "error") {
          log(
            "yellow",
            "lyrics",
            `provider ${event.provider} error: ${event.message}`,
          );
        } else if (event.type === "done") {
          if (bestCandidate && shouldCacheLyricsCandidate(bestCandidate)) {
            const currentProviders =
              useLyricsStore.getState().availableProviders;
            lyricsCache.set(trackId, bestCandidate, currentProviders);
            void linerDb.putLyrics({
              trackId,
              syncLevel: bestCandidate.syncLevel,
              quality: bestCandidate.quality.total,
              activeProvider: bestCandidate.provider,
              availableProviders: currentProviders,
              rawLyrics: bestCandidate.lyrics.content,
              rawFormat: bestCandidate.lyrics.format,
              candidate: bestCandidate,
              lastCheckedAt: Date.now(),
              updatedAt: Date.now(),
            });
          }
          log(
            "cyan",
            "lyrics",
            event.best
              ? `done, best=${event.best.provider} q=${event.best.quality}`
              : "done, no lyrics found",
          );
          break;
        }
      }
    } catch (error) {
      if (token !== this.lyricsLoadToken || controller.signal.aborted) return;
      log(
        "red",
        "lyrics",
        `stream failed: ${error instanceof Error ? error.message : String(error)}`,
      );
      if (!cached) {
        useLyricsStore.getState().setLyricsState({
          lyricsError: "Failed to load lyrics.",
        });
      }
    } finally {
      if (token === this.lyricsLoadToken) {
        useLyricsStore.getState().setLyricsState({ lyricsLoading: false });
      }
    }
  }
}

export const playerEngine = new PlayerEngine();
