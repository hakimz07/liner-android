import { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { AnimatePresence, motion } from "framer-motion";
import { isWindowDraggingActive } from "@/shared/hooks";
import { isEscapeGuarded } from "@/shared/utils/escapeGuard";

export interface DialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  children: React.ReactNode;
  maxWidth?: number | string;
  minHeight?: number | string;
  maxHeight?: number | string;
  className?: string;
  zIndex?: number;
}

const activeDialogs: Array<() => void> = [];

export default function Dialog({
  open,
  onOpenChange,
  children,
  maxWidth = 360,
  minHeight,
  maxHeight,
  className = "",
  zIndex,
}: DialogProps) {
  const [mounted, setMounted] = useState(false);
  const pointerStartRef = useRef<{ x: number; y: number; target: EventTarget | null } | null>(null);

  useEffect(() => {
    setMounted(true);
  }, []);

  useEffect(() => {
    if (!open) return;

    const closeHandler = () => onOpenChange(false);
    activeDialogs.push(closeHandler);

    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        // A recorder (or similar) is waiting for keys: let it cancel itself first
        if (isEscapeGuarded()) return;
        // Only the top-most open dialog closes on Escape; parent dialogs stay open
        if (activeDialogs[activeDialogs.length - 1] !== closeHandler) {
          return;
        }
        e.preventDefault();
        e.stopPropagation();
        e.stopImmediatePropagation();
        onOpenChange(false);
      }
    };

    window.addEventListener("keydown", onKey, true);
    return () => {
      window.removeEventListener("keydown", onKey, true);
      const idx = activeDialogs.indexOf(closeHandler);
      if (idx !== -1) {
        activeDialogs.splice(idx, 1);
      }
    };
  }, [open, onOpenChange]);

  if (!mounted || typeof document === "undefined") return null;

  const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    pointerStartRef.current = {
      x: e.clientX,
      y: e.clientY,
      target: e.target,
    };
  };

  const handleBackdropClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (isWindowDraggingActive()) {
      return;
    }
    const start = pointerStartRef.current;
    if (start) {
      const dist = Math.hypot(e.clientX - start.x, e.clientY - start.y);
      if (dist > 6) {
        return;
      }
      if (start.target !== e.currentTarget && (start.target as HTMLElement)?.closest?.("[data-dialog-container]")) {
        return;
      }
    }
    onOpenChange(false);
  };

  return createPortal(
    <AnimatePresence>
      {open && (
        <motion.div
          key="dialog-backdrop"
          data-dialog-backdrop="true"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
          className="fixed inset-0 z-[199] bg-black/15 backdrop-blur-[2px] rounded-4xl overflow-hidden"
          style={zIndex ? { zIndex: zIndex - 1 } : undefined}
          onPointerDown={handlePointerDown}
          onClick={handleBackdropClick}
        />
      )}
      {open && (
        <motion.div
          key="dialog"
          data-dialog-container="true"
          className="fixed inset-0 z-[200] flex items-center justify-center pointer-events-none"
          style={zIndex ? { zIndex } : undefined}
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.97, y: 10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.97, y: 10 }}
            transition={{ duration: 0.2, ease: [0.22, 1, 0.36, 1] }}
            className={`pointer-events-auto w-full mx-[16px] max-h-[85vh] flex flex-col rounded-[20px] border-0 bg-[#f5f5f7]/92 dark:bg-[#161618]/90 backdrop-blur-2xl backdrop-saturate-150 shadow-[0_24px_80px_rgba(0,0,0,0.35)] overflow-hidden relative ${
              className || "pt-[20px]"
            }`}
            style={{ maxWidth, minHeight, ...(maxHeight ? { maxHeight } : {}) }}
          >
            {children}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>,
    document.body,
  );
}
